          <!doctype html>
    <html class="no-js" lang="zxx">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Cursos y Diplomados</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="manifest" href="site.webmanifest">
        <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>

        <!-- CSS here -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/fontawesome-all.min.css">
        <link rel="stylesheet" href="css/themify-icons.css">
        <link rel="stylesheet" href="css/slick.css">
        <link rel="stylesheet" href="css/meanmenu.css">
        <link rel="stylesheet" href="css/default.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
    </head>
     <body>
             <header id="home">
            <div class="header-area">
                    <!-- header-top -->
                    <div class="header-top primary-bg">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6 col-lg-6 col-md-6 col-12">
                                    <div class="header-contact-info d-flex">
                                        <div class="header-contact header-contact-phone">
                                            <span class="ti-headphone"></span>
                                            <p class="phone-number">4 32 00 35</p>
                                        </div>
                                        <div class="header-contact header-contact-email">
                                            <span class="ti-email"></span>
                                            <p class="email-name">info@cursosydiplomados.com.co
</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                    <div class="header-social-icon-list">
                                        <ul>
                                            <li><a href="#"><span class="ti-facebook"></span></a></li>
                                            <li><a href="#"><span class="fab fa-whatsapp"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /end header-top -->
                    <!-- header-bottom -->
                    <div class="header-bottom-area header-sticky" style="transition: .6s;">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-xl-3 col-lg-2 col-md-6 col-6">
                                    <div class="logo">
                                        <a href="index.html">
                                            <img src="img/logo/logo.png" width="150px" alt="">                                                 

                                            
                                        </a>
                                    </div>
                                </div>
                                <div class="col-xl-9 col-lg-10 col-md-6 col-6">

                                    <div class="main-menu f-right">
                                        <nav id="mobile-menu" style="display: block;">
                                            <ul>
                                                <li>
                                                    <a href="index.html">INICIO</a>
                                                </li>
                                                <li>
                                                    <a href="index.html">CURSOS</a>
                                                    <ul class="submenu">
                                                      <li>
                                                        <a href="course_details_Ingles.html">INGLÉS</a>
                                                    </li>
                                                    <li>
                                                        <a href="course_details_Frances.html">FRANCÉS</a>
                                                    </li>
                                                    <li>
                                                        <a href="course_details_Sistemas.html">SISTEMAS</a>
                                                    </li>
                                                    <li>
                                                        <a href="course_details_Tecnicocontaduria.html">TÉCNICO EN CONTADURIA</a>
                                                    </li>
                                                    <li>
                                                        <a href="course_details_Callcenter.html">CALL CENTER</a>
                                                    </li>
                                                    <li>
                                                        <a href="course_details_Administracionempresas.html">ADMINISTRACIÓN DE EMPRESAS</a>
                                                    </li>
                                                    <li>
                                                        <a href="course_details_HoteleriaTurismo.html">HOTELERIA Y TURISMO</a>
                                                    </li>
                                                    <li>
                                                        <a href="course_details_Aduana.html">ADUANAS</a>
                                                    </li>


                                                </ul>
                                            </li>
                                            <li>
                                               
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mobile-menu"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /end header-bottom -->
                <!-- /end header-bottom -->
            </div>
        </header>
        </body>